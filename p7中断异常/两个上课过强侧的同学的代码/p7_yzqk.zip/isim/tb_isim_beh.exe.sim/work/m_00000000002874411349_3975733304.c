/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/p7/p7_yzqk/CP0.v";
static int ng1[] = {4, 0};
static unsigned int ng2[] = {0U, 0U};
static int ng3[] = {0, 0};
static unsigned int ng4[] = {406271234U, 0U};
static int ng5[] = {12, 0};
static int ng6[] = {13, 0};
static int ng7[] = {14, 0};
static int ng8[] = {15, 0};
static int ng9[] = {1, 0};



static void Cont_40_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 3744U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 1152U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_minus(t4, 32, t3, 32, t2, 32);
    t5 = (t0 + 5192);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 5092);
    *((int *)t10) = 1;

LAB1:    return;
}

static void NetDecl_59_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    t1 = (t0 + 3888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 2760);
    t4 = (t2 + 36U);
    t5 = *((char **)t4);
    t6 = (t0 + 2668);
    t7 = (t6 + 36U);
    t8 = *((char **)t7);
    t9 = ((char*)((ng2)));
    t10 = (t0 + 2576);
    t11 = (t10 + 36U);
    t12 = *((char **)t11);
    t13 = ((char*)((ng2)));
    xsi_vlogtype_concat(t3, 32, 32, 5U, t13, 16, t12, 6, t9, 8, t8, 1, t5, 1);
    t14 = (t0 + 5228);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    memcpy(t18, t3, 8);
    xsi_driver_vfirst_trans(t14, 0, 31U);
    t19 = (t0 + 5100);
    *((int *)t19) = 1;

LAB1:    return;
}

static void NetDecl_64_2(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 4032U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng2)));
    t4 = (t0 + 3036);
    t5 = (t4 + 36U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng2)));
    t8 = (t0 + 2944);
    t9 = (t8 + 36U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng2)));
    t12 = (t0 + 2852);
    t13 = (t12 + 36U);
    t14 = *((char **)t13);
    xsi_vlogtype_concat(t3, 32, 32, 6U, t14, 1, t11, 15, t10, 6, t7, 3, t6, 5, t2, 2);
    t15 = (t0 + 5264);
    t16 = (t15 + 32U);
    t17 = *((char **)t16);
    t18 = (t17 + 40U);
    t19 = *((char **)t18);
    memcpy(t19, t3, 8);
    xsi_driver_vfirst_trans(t15, 0, 31U);
    t20 = (t0 + 5108);
    *((int *)t20) = 1;

LAB1:    return;
}

static void Initial_70_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(70, ng0);

LAB2:    xsi_set_current_line(71, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2576);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 6, 0LL);
    xsi_set_current_line(72, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2760);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 1, 0LL);
    xsi_set_current_line(74, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2852);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 1, 0LL);
    xsi_set_current_line(75, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2944);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 6, 0LL);
    xsi_set_current_line(76, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 3036);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 5, 0LL);
    xsi_set_current_line(77, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 3128);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 32, 0LL);
    xsi_set_current_line(78, ng0);
    t1 = ((char*)((ng4)));
    t2 = (t0 + 3220);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 32, 0LL);

LAB1:    return;
}

static void Cont_80_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 4320U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 3128);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 5300);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 5116);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_81_5(char *t0)
{
    char t3[8];
    char t4[8];
    char t13[8];
    char t25[8];
    char t67[8];
    char t99[8];
    char t110[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    int t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    int t91;
    int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    char *t100;
    char *t101;
    char *t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t109;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t114;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    char *t124;
    char *t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    int t134;
    int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    char *t142;
    char *t143;
    char *t144;
    char *t145;
    char *t146;
    unsigned int t147;
    unsigned int t148;
    char *t149;
    unsigned int t150;
    unsigned int t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    char *t155;

LAB0:    t1 = (t0 + 4464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 1336U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (t7 >> 0);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t6);
    t10 = (t9 >> 0);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t11 & 63U);
    t12 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t12 & 63U);
    t14 = (t0 + 2576);
    t15 = (t14 + 36U);
    t16 = *((char **)t15);
    memset(t13, 0, 8);
    t17 = (t13 + 4);
    t18 = (t16 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (t19 >> 0);
    *((unsigned int *)t13) = t20;
    t21 = *((unsigned int *)t18);
    t22 = (t21 >> 0);
    *((unsigned int *)t17) = t22;
    t23 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t23 & 63U);
    t24 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t24 & 63U);
    t26 = *((unsigned int *)t4);
    t27 = *((unsigned int *)t13);
    t28 = (t26 & t27);
    *((unsigned int *)t25) = t28;
    t29 = (t4 + 4);
    t30 = (t13 + 4);
    t31 = (t25 + 4);
    t32 = *((unsigned int *)t29);
    t33 = *((unsigned int *)t30);
    t34 = (t32 | t33);
    *((unsigned int *)t31) = t34;
    t35 = *((unsigned int *)t31);
    t36 = (t35 != 0);
    if (t36 == 1)
        goto LAB4;

LAB5:
LAB6:    memset(t3, 0, 8);
    t57 = (t25 + 4);
    t58 = *((unsigned int *)t57);
    t59 = (~(t58));
    t60 = *((unsigned int *)t25);
    t61 = (t60 & t59);
    t62 = (t61 & 63U);
    if (t62 != 0)
        goto LAB7;

LAB8:    if (*((unsigned int *)t57) != 0)
        goto LAB9;

LAB10:    t64 = (t0 + 2760);
    t65 = (t64 + 36U);
    t66 = *((char **)t65);
    t68 = *((unsigned int *)t3);
    t69 = *((unsigned int *)t66);
    t70 = (t68 & t69);
    *((unsigned int *)t67) = t70;
    t71 = (t3 + 4);
    t72 = (t66 + 4);
    t73 = (t67 + 4);
    t74 = *((unsigned int *)t71);
    t75 = *((unsigned int *)t72);
    t76 = (t74 | t75);
    *((unsigned int *)t73) = t76;
    t77 = *((unsigned int *)t73);
    t78 = (t77 != 0);
    if (t78 == 1)
        goto LAB11;

LAB12:
LAB13:    t100 = (t0 + 2668);
    t101 = (t100 + 36U);
    t102 = *((char **)t101);
    memset(t99, 0, 8);
    t103 = (t102 + 4);
    t104 = *((unsigned int *)t103);
    t105 = (~(t104));
    t106 = *((unsigned int *)t102);
    t107 = (t106 & t105);
    t108 = (t107 & 1U);
    if (t108 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t103) == 0)
        goto LAB14;

LAB16:    t109 = (t99 + 4);
    *((unsigned int *)t99) = 1;
    *((unsigned int *)t109) = 1;

LAB17:    t111 = *((unsigned int *)t67);
    t112 = *((unsigned int *)t99);
    t113 = (t111 & t112);
    *((unsigned int *)t110) = t113;
    t114 = (t67 + 4);
    t115 = (t99 + 4);
    t116 = (t110 + 4);
    t117 = *((unsigned int *)t114);
    t118 = *((unsigned int *)t115);
    t119 = (t117 | t118);
    *((unsigned int *)t116) = t119;
    t120 = *((unsigned int *)t116);
    t121 = (t120 != 0);
    if (t121 == 1)
        goto LAB18;

LAB19:
LAB20:    t142 = (t0 + 5336);
    t143 = (t142 + 32U);
    t144 = *((char **)t143);
    t145 = (t144 + 40U);
    t146 = *((char **)t145);
    memset(t146, 0, 8);
    t147 = 1U;
    t148 = t147;
    t149 = (t110 + 4);
    t150 = *((unsigned int *)t110);
    t147 = (t147 & t150);
    t151 = *((unsigned int *)t149);
    t148 = (t148 & t151);
    t152 = (t146 + 4);
    t153 = *((unsigned int *)t146);
    *((unsigned int *)t146) = (t153 | t147);
    t154 = *((unsigned int *)t152);
    *((unsigned int *)t152) = (t154 | t148);
    xsi_driver_vfirst_trans(t142, 0, 0);
    t155 = (t0 + 5124);
    *((int *)t155) = 1;

LAB1:    return;
LAB4:    t37 = *((unsigned int *)t25);
    t38 = *((unsigned int *)t31);
    *((unsigned int *)t25) = (t37 | t38);
    t39 = (t4 + 4);
    t40 = (t13 + 4);
    t41 = *((unsigned int *)t4);
    t42 = (~(t41));
    t43 = *((unsigned int *)t39);
    t44 = (~(t43));
    t45 = *((unsigned int *)t13);
    t46 = (~(t45));
    t47 = *((unsigned int *)t40);
    t48 = (~(t47));
    t49 = (t42 & t44);
    t50 = (t46 & t48);
    t51 = (~(t49));
    t52 = (~(t50));
    t53 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t53 & t51);
    t54 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t54 & t52);
    t55 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t55 & t51);
    t56 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t56 & t52);
    goto LAB6;

LAB7:    *((unsigned int *)t3) = 1;
    goto LAB10;

LAB9:    t63 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t63) = 1;
    goto LAB10;

LAB11:    t79 = *((unsigned int *)t67);
    t80 = *((unsigned int *)t73);
    *((unsigned int *)t67) = (t79 | t80);
    t81 = (t3 + 4);
    t82 = (t66 + 4);
    t83 = *((unsigned int *)t3);
    t84 = (~(t83));
    t85 = *((unsigned int *)t81);
    t86 = (~(t85));
    t87 = *((unsigned int *)t66);
    t88 = (~(t87));
    t89 = *((unsigned int *)t82);
    t90 = (~(t89));
    t91 = (t84 & t86);
    t92 = (t88 & t90);
    t93 = (~(t91));
    t94 = (~(t92));
    t95 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t95 & t93);
    t96 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t96 & t94);
    t97 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t97 & t93);
    t98 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t98 & t94);
    goto LAB13;

LAB14:    *((unsigned int *)t99) = 1;
    goto LAB17;

LAB18:    t122 = *((unsigned int *)t110);
    t123 = *((unsigned int *)t116);
    *((unsigned int *)t110) = (t122 | t123);
    t124 = (t67 + 4);
    t125 = (t99 + 4);
    t126 = *((unsigned int *)t67);
    t127 = (~(t126));
    t128 = *((unsigned int *)t124);
    t129 = (~(t128));
    t130 = *((unsigned int *)t99);
    t131 = (~(t130));
    t132 = *((unsigned int *)t125);
    t133 = (~(t132));
    t134 = (t127 & t129);
    t135 = (t131 & t133);
    t136 = (~(t134));
    t137 = (~(t135));
    t138 = *((unsigned int *)t116);
    *((unsigned int *)t116) = (t138 & t136);
    t139 = *((unsigned int *)t116);
    *((unsigned int *)t116) = (t139 & t137);
    t140 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t140 & t136);
    t141 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t141 & t137);
    goto LAB20;

}

static void Cont_82_6(char *t0)
{
    char t4[8];
    char t18[8];
    char t29[8];
    char t40[8];
    char t48[8];
    char t80[8];
    char t88[8];
    char *t1;
    char *t2;
    char *t3;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    int t72;
    int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t87;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    char *t93;
    char *t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    unsigned int t121;
    unsigned int t122;
    char *t123;
    unsigned int t124;
    unsigned int t125;
    char *t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;

LAB0:    t1 = (t0 + 4608U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(82, ng0);
    t2 = (t0 + 2348U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t3 + 4);
    t5 = *((unsigned int *)t2);
    t6 = (~(t5));
    t7 = *((unsigned int *)t3);
    t8 = (t7 & t6);
    t9 = (t8 & 1U);
    if (t9 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t11 = (t4 + 4);
    t12 = *((unsigned int *)t4);
    t13 = (!(t12));
    t14 = *((unsigned int *)t11);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    memcpy(t88, t4, 8);

LAB10:    t116 = (t0 + 5372);
    t117 = (t116 + 32U);
    t118 = *((char **)t117);
    t119 = (t118 + 40U);
    t120 = *((char **)t119);
    memset(t120, 0, 8);
    t121 = 1U;
    t122 = t121;
    t123 = (t88 + 4);
    t124 = *((unsigned int *)t88);
    t121 = (t121 & t124);
    t125 = *((unsigned int *)t123);
    t122 = (t122 & t125);
    t126 = (t120 + 4);
    t127 = *((unsigned int *)t120);
    *((unsigned int *)t120) = (t127 | t121);
    t128 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t128 | t122);
    xsi_driver_vfirst_trans(t116, 0, 0);
    t129 = (t0 + 5132);
    *((int *)t129) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t10 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB7;

LAB8:    t16 = (t0 + 1244U);
    t17 = *((char **)t16);
    memset(t18, 0, 8);
    t16 = (t17 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (~(t19));
    t21 = *((unsigned int *)t17);
    t22 = (t21 & t20);
    t23 = (t22 & 31U);
    if (t23 != 0)
        goto LAB11;

LAB12:    if (*((unsigned int *)t16) != 0)
        goto LAB13;

LAB14:    t25 = (t18 + 4);
    t26 = *((unsigned int *)t18);
    t27 = *((unsigned int *)t25);
    t28 = (t26 || t27);
    if (t28 > 0)
        goto LAB15;

LAB16:    memcpy(t48, t18, 8);

LAB17:    memset(t80, 0, 8);
    t81 = (t48 + 4);
    t82 = *((unsigned int *)t81);
    t83 = (~(t82));
    t84 = *((unsigned int *)t48);
    t85 = (t84 & t83);
    t86 = (t85 & 1U);
    if (t86 != 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t81) != 0)
        goto LAB31;

LAB32:    t89 = *((unsigned int *)t4);
    t90 = *((unsigned int *)t80);
    t91 = (t89 | t90);
    *((unsigned int *)t88) = t91;
    t92 = (t4 + 4);
    t93 = (t80 + 4);
    t94 = (t88 + 4);
    t95 = *((unsigned int *)t92);
    t96 = *((unsigned int *)t93);
    t97 = (t95 | t96);
    *((unsigned int *)t94) = t97;
    t98 = *((unsigned int *)t94);
    t99 = (t98 != 0);
    if (t99 == 1)
        goto LAB33;

LAB34:
LAB35:    goto LAB10;

LAB11:    *((unsigned int *)t18) = 1;
    goto LAB14;

LAB13:    t24 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB14;

LAB15:    t30 = (t0 + 2668);
    t31 = (t30 + 36U);
    t32 = *((char **)t31);
    memset(t29, 0, 8);
    t33 = (t32 + 4);
    t34 = *((unsigned int *)t33);
    t35 = (~(t34));
    t36 = *((unsigned int *)t32);
    t37 = (t36 & t35);
    t38 = (t37 & 1U);
    if (t38 != 0)
        goto LAB21;

LAB19:    if (*((unsigned int *)t33) == 0)
        goto LAB18;

LAB20:    t39 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t39) = 1;

LAB21:    memset(t40, 0, 8);
    t41 = (t29 + 4);
    t42 = *((unsigned int *)t41);
    t43 = (~(t42));
    t44 = *((unsigned int *)t29);
    t45 = (t44 & t43);
    t46 = (t45 & 1U);
    if (t46 != 0)
        goto LAB22;

LAB23:    if (*((unsigned int *)t41) != 0)
        goto LAB24;

LAB25:    t49 = *((unsigned int *)t18);
    t50 = *((unsigned int *)t40);
    t51 = (t49 & t50);
    *((unsigned int *)t48) = t51;
    t52 = (t18 + 4);
    t53 = (t40 + 4);
    t54 = (t48 + 4);
    t55 = *((unsigned int *)t52);
    t56 = *((unsigned int *)t53);
    t57 = (t55 | t56);
    *((unsigned int *)t54) = t57;
    t58 = *((unsigned int *)t54);
    t59 = (t58 != 0);
    if (t59 == 1)
        goto LAB26;

LAB27:
LAB28:    goto LAB17;

LAB18:    *((unsigned int *)t29) = 1;
    goto LAB21;

LAB22:    *((unsigned int *)t40) = 1;
    goto LAB25;

LAB24:    t47 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t47) = 1;
    goto LAB25;

LAB26:    t60 = *((unsigned int *)t48);
    t61 = *((unsigned int *)t54);
    *((unsigned int *)t48) = (t60 | t61);
    t62 = (t18 + 4);
    t63 = (t40 + 4);
    t64 = *((unsigned int *)t18);
    t65 = (~(t64));
    t66 = *((unsigned int *)t62);
    t67 = (~(t66));
    t68 = *((unsigned int *)t40);
    t69 = (~(t68));
    t70 = *((unsigned int *)t63);
    t71 = (~(t70));
    t72 = (t65 & t67);
    t73 = (t69 & t71);
    t74 = (~(t72));
    t75 = (~(t73));
    t76 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t76 & t74);
    t77 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t77 & t75);
    t78 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t78 & t74);
    t79 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t79 & t75);
    goto LAB28;

LAB29:    *((unsigned int *)t80) = 1;
    goto LAB32;

LAB31:    t87 = (t80 + 4);
    *((unsigned int *)t80) = 1;
    *((unsigned int *)t87) = 1;
    goto LAB32;

LAB33:    t100 = *((unsigned int *)t88);
    t101 = *((unsigned int *)t94);
    *((unsigned int *)t88) = (t100 | t101);
    t102 = (t4 + 4);
    t103 = (t80 + 4);
    t104 = *((unsigned int *)t102);
    t105 = (~(t104));
    t106 = *((unsigned int *)t4);
    t107 = (t106 & t105);
    t108 = *((unsigned int *)t103);
    t109 = (~(t108));
    t110 = *((unsigned int *)t80);
    t111 = (t110 & t109);
    t112 = (~(t107));
    t113 = (~(t111));
    t114 = *((unsigned int *)t94);
    *((unsigned int *)t94) = (t114 & t112);
    t115 = *((unsigned int *)t94);
    *((unsigned int *)t94) = (t115 & t113);
    goto LAB35;

}

static void Cont_83_7(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t39[8];
    char t40[8];
    char t42[8];
    char t75[8];
    char t76[8];
    char t78[8];
    char t111[8];
    char t112[8];
    char t114[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t41;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t77;
    char *t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;
    char *t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t105;
    char *t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    char *t113;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    char *t141;
    char *t142;
    char *t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    char *t148;
    char *t149;
    char *t150;
    char *t151;
    char *t152;
    char *t153;
    char *t154;

LAB0:    t1 = (t0 + 4752U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 876U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t35 = *((unsigned int *)t4);
    t36 = (~(t35));
    t37 = *((unsigned int *)t29);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t39, 8);

LAB20:    t149 = (t0 + 5408);
    t150 = (t149 + 32U);
    t151 = *((char **)t150);
    t152 = (t151 + 40U);
    t153 = *((char **)t152);
    memcpy(t153, t3, 8);
    xsi_driver_vfirst_trans(t149, 0, 31);
    t154 = (t0 + 5140);
    *((int *)t154) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 2164U);
    t34 = *((char **)t33);
    goto LAB13;

LAB14:    t33 = (t0 + 876U);
    t41 = *((char **)t33);
    t33 = ((char*)((ng6)));
    memset(t42, 0, 8);
    t43 = (t41 + 4);
    t44 = (t33 + 4);
    t45 = *((unsigned int *)t41);
    t46 = *((unsigned int *)t33);
    t47 = (t45 ^ t46);
    t48 = *((unsigned int *)t43);
    t49 = *((unsigned int *)t44);
    t50 = (t48 ^ t49);
    t51 = (t47 | t50);
    t52 = *((unsigned int *)t43);
    t53 = *((unsigned int *)t44);
    t54 = (t52 | t53);
    t55 = (~(t54));
    t56 = (t51 & t55);
    if (t56 != 0)
        goto LAB24;

LAB21:    if (t54 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t42) = 1;

LAB24:    memset(t40, 0, 8);
    t58 = (t42 + 4);
    t59 = *((unsigned int *)t58);
    t60 = (~(t59));
    t61 = *((unsigned int *)t42);
    t62 = (t61 & t60);
    t63 = (t62 & 1U);
    if (t63 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t58) != 0)
        goto LAB27;

LAB28:    t65 = (t40 + 4);
    t66 = *((unsigned int *)t40);
    t67 = *((unsigned int *)t65);
    t68 = (t66 || t67);
    if (t68 > 0)
        goto LAB29;

LAB30:    t71 = *((unsigned int *)t40);
    t72 = (~(t71));
    t73 = *((unsigned int *)t65);
    t74 = (t72 || t73);
    if (t74 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t65) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t40) > 0)
        goto LAB35;

LAB36:    memcpy(t39, t75, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t34, 32, t39, 32);
    goto LAB20;

LAB18:    memcpy(t3, t34, 8);
    goto LAB20;

LAB23:    t57 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t57) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t40) = 1;
    goto LAB28;

LAB27:    t64 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t64) = 1;
    goto LAB28;

LAB29:    t69 = (t0 + 2256U);
    t70 = *((char **)t69);
    goto LAB30;

LAB31:    t69 = (t0 + 876U);
    t77 = *((char **)t69);
    t69 = ((char*)((ng7)));
    memset(t78, 0, 8);
    t79 = (t77 + 4);
    t80 = (t69 + 4);
    t81 = *((unsigned int *)t77);
    t82 = *((unsigned int *)t69);
    t83 = (t81 ^ t82);
    t84 = *((unsigned int *)t79);
    t85 = *((unsigned int *)t80);
    t86 = (t84 ^ t85);
    t87 = (t83 | t86);
    t88 = *((unsigned int *)t79);
    t89 = *((unsigned int *)t80);
    t90 = (t88 | t89);
    t91 = (~(t90));
    t92 = (t87 & t91);
    if (t92 != 0)
        goto LAB41;

LAB38:    if (t90 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t78) = 1;

LAB41:    memset(t76, 0, 8);
    t94 = (t78 + 4);
    t95 = *((unsigned int *)t94);
    t96 = (~(t95));
    t97 = *((unsigned int *)t78);
    t98 = (t97 & t96);
    t99 = (t98 & 1U);
    if (t99 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t94) != 0)
        goto LAB44;

LAB45:    t101 = (t76 + 4);
    t102 = *((unsigned int *)t76);
    t103 = *((unsigned int *)t101);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB46;

LAB47:    t107 = *((unsigned int *)t76);
    t108 = (~(t107));
    t109 = *((unsigned int *)t101);
    t110 = (t108 || t109);
    if (t110 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t101) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t76) > 0)
        goto LAB52;

LAB53:    memcpy(t75, t111, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t39, 32, t70, 32, t75, 32);
    goto LAB37;

LAB35:    memcpy(t39, t70, 8);
    goto LAB37;

LAB40:    t93 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t93) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t76) = 1;
    goto LAB45;

LAB44:    t100 = (t76 + 4);
    *((unsigned int *)t76) = 1;
    *((unsigned int *)t100) = 1;
    goto LAB45;

LAB46:    t105 = (t0 + 1796U);
    t106 = *((char **)t105);
    goto LAB47;

LAB48:    t105 = (t0 + 876U);
    t113 = *((char **)t105);
    t105 = ((char*)((ng8)));
    memset(t114, 0, 8);
    t115 = (t113 + 4);
    t116 = (t105 + 4);
    t117 = *((unsigned int *)t113);
    t118 = *((unsigned int *)t105);
    t119 = (t117 ^ t118);
    t120 = *((unsigned int *)t115);
    t121 = *((unsigned int *)t116);
    t122 = (t120 ^ t121);
    t123 = (t119 | t122);
    t124 = *((unsigned int *)t115);
    t125 = *((unsigned int *)t116);
    t126 = (t124 | t125);
    t127 = (~(t126));
    t128 = (t123 & t127);
    if (t128 != 0)
        goto LAB58;

LAB55:    if (t126 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t114) = 1;

LAB58:    memset(t112, 0, 8);
    t130 = (t114 + 4);
    t131 = *((unsigned int *)t130);
    t132 = (~(t131));
    t133 = *((unsigned int *)t114);
    t134 = (t133 & t132);
    t135 = (t134 & 1U);
    if (t135 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t130) != 0)
        goto LAB61;

LAB62:    t137 = (t112 + 4);
    t138 = *((unsigned int *)t112);
    t139 = *((unsigned int *)t137);
    t140 = (t138 || t139);
    if (t140 > 0)
        goto LAB63;

LAB64:    t144 = *((unsigned int *)t112);
    t145 = (~(t144));
    t146 = *((unsigned int *)t137);
    t147 = (t145 || t146);
    if (t147 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t137) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t112) > 0)
        goto LAB69;

LAB70:    memcpy(t111, t148, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t75, 32, t106, 32, t111, 32);
    goto LAB54;

LAB52:    memcpy(t75, t106, 8);
    goto LAB54;

LAB57:    t129 = (t114 + 4);
    *((unsigned int *)t114) = 1;
    *((unsigned int *)t129) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t112) = 1;
    goto LAB62;

LAB61:    t136 = (t112 + 4);
    *((unsigned int *)t112) = 1;
    *((unsigned int *)t136) = 1;
    goto LAB62;

LAB63:    t141 = (t0 + 3220);
    t142 = (t141 + 36U);
    t143 = *((char **)t142);
    goto LAB64;

LAB65:    t148 = ((char*)((ng3)));
    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t111, 32, t143, 32, t148, 32);
    goto LAB71;

LAB69:    memcpy(t111, t143, 8);
    goto LAB71;

}

static void Always_88_8(char *t0)
{
    char t14[8];
    char t15[8];
    char t25[8];
    char t33[8];
    char t46[8];
    char t47[8];
    char t48[8];
    char t89[8];
    char t100[8];
    char t105[8];
    char t107[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    int t13;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    char *t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    char *t88;
    char *t90;
    char *t91;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    char *t99;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t106;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    char *t117;

LAB0:    t1 = (t0 + 4896U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(88, ng0);
    t2 = (t0 + 5148);
    *((int *)t2) = 1;
    t3 = (t0 + 4924);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(88, ng0);

LAB5:    xsi_set_current_line(90, ng0);
    t4 = (t0 + 600U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(100, ng0);

LAB10:    xsi_set_current_line(101, ng0);
    t2 = (t0 + 1336U);
    t3 = *((char **)t2);
    t2 = (t0 + 2944);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 6, 0LL);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 1428U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB11;

LAB12:
LAB13:    xsi_set_current_line(108, ng0);
    t2 = (t0 + 2348U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB21;

LAB22:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 1244U);
    t3 = *((char **)t2);
    memset(t14, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 31U);
    if (t10 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t2) != 0)
        goto LAB53;

LAB54:    t11 = (t14 + 4);
    t17 = *((unsigned int *)t14);
    t18 = *((unsigned int *)t11);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB55;

LAB56:    memcpy(t33, t14, 8);

LAB57:    t70 = (t33 + 4);
    t71 = *((unsigned int *)t70);
    t72 = (~(t71));
    t73 = *((unsigned int *)t33);
    t74 = (t73 & t72);
    t75 = (t74 != 0);
    if (t75 > 0)
        goto LAB69;

LAB70:
LAB71:
LAB23:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 1612U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB99;

LAB100:
LAB101:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 1520U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB102;

LAB103:
LAB104:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(90, ng0);

LAB9:    xsi_set_current_line(91, ng0);
    t11 = ((char*)((ng2)));
    t12 = (t0 + 2576);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 6, 0LL);
    xsi_set_current_line(92, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(93, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2760);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2852);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(95, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2944);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 6, 0LL);
    xsi_set_current_line(96, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3036);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(97, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3128);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3220);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB8;

LAB11:    xsi_set_current_line(102, ng0);

LAB14:    xsi_set_current_line(103, ng0);
    t4 = (t0 + 968U);
    t5 = *((char **)t4);

LAB15:    t4 = ((char*)((ng5)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 5, t4, 32);
    if (t13 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng7)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 5, t2, 32);
    if (t13 == 1)
        goto LAB18;

LAB19:
LAB20:    goto LAB13;

LAB16:    xsi_set_current_line(104, ng0);
    t11 = (t0 + 1060U);
    t12 = *((char **)t11);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t16 = (t12 + 4);
    t17 = *((unsigned int *)t12);
    t18 = (t17 >> 0);
    t19 = (t18 & 1);
    *((unsigned int *)t15) = t19;
    t20 = *((unsigned int *)t16);
    t21 = (t20 >> 0);
    t22 = (t21 & 1);
    *((unsigned int *)t11) = t22;
    t23 = (t0 + 1060U);
    t24 = *((char **)t23);
    memset(t25, 0, 8);
    t23 = (t25 + 4);
    t26 = (t24 + 4);
    t27 = *((unsigned int *)t24);
    t28 = (t27 >> 1);
    t29 = (t28 & 1);
    *((unsigned int *)t25) = t29;
    t30 = *((unsigned int *)t26);
    t31 = (t30 >> 1);
    t32 = (t31 & 1);
    *((unsigned int *)t23) = t32;
    t34 = (t0 + 1060U);
    t35 = *((char **)t34);
    memset(t33, 0, 8);
    t34 = (t33 + 4);
    t36 = (t35 + 4);
    t37 = *((unsigned int *)t35);
    t38 = (t37 >> 10);
    *((unsigned int *)t33) = t38;
    t39 = *((unsigned int *)t36);
    t40 = (t39 >> 10);
    *((unsigned int *)t34) = t40;
    t41 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t41 & 63U);
    t42 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t42 & 63U);
    xsi_vlogtype_concat(t14, 8, 8, 3U, t33, 6, t25, 1, t15, 1);
    t43 = (t0 + 2760);
    xsi_vlogvar_wait_assign_value(t43, t14, 0, 0, 1, 0LL);
    t44 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t44, t14, 1, 0, 1, 0LL);
    t45 = (t0 + 2576);
    xsi_vlogvar_wait_assign_value(t45, t14, 2, 0, 6, 0LL);
    goto LAB20;

LAB18:    xsi_set_current_line(105, ng0);
    t3 = ((char*)((ng2)));
    t4 = (t0 + 1060U);
    t11 = *((char **)t4);
    memset(t15, 0, 8);
    t4 = (t15 + 4);
    t12 = (t11 + 4);
    t6 = *((unsigned int *)t11);
    t7 = (t6 >> 2);
    *((unsigned int *)t15) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 2);
    *((unsigned int *)t4) = t9;
    t10 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t10 & 1073741823U);
    t17 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t17 & 1073741823U);
    xsi_vlogtype_concat(t14, 32, 32, 2U, t15, 30, t3, 2);
    t16 = (t0 + 3128);
    xsi_vlogvar_wait_assign_value(t16, t14, 0, 0, 32, 0LL);
    goto LAB20;

LAB21:    xsi_set_current_line(108, ng0);

LAB24:    xsi_set_current_line(109, ng0);
    t4 = (t0 + 1980U);
    t11 = *((char **)t4);
    memset(t15, 0, 8);
    t4 = (t11 + 4);
    t17 = *((unsigned int *)t4);
    t18 = (~(t17));
    t19 = *((unsigned int *)t11);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t4) != 0)
        goto LAB27;

LAB28:    t16 = (t15 + 4);
    t22 = *((unsigned int *)t15);
    t27 = *((unsigned int *)t16);
    t28 = (t22 || t27);
    if (t28 > 0)
        goto LAB29;

LAB30:    t39 = *((unsigned int *)t15);
    t40 = (~(t39));
    t41 = *((unsigned int *)t16);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t16) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t15) > 0)
        goto LAB35;

LAB36:    memcpy(t14, t47, 8);

LAB37:    t55 = (t0 + 3128);
    xsi_vlogvar_wait_assign_value(t55, t14, 0, 0, 32, 0LL);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 1980U);
    t3 = *((char **)t2);
    memset(t15, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t2) != 0)
        goto LAB40;

LAB41:    t11 = (t15 + 4);
    t17 = *((unsigned int *)t15);
    t18 = *((unsigned int *)t11);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB42;

LAB43:    t20 = *((unsigned int *)t15);
    t21 = (~(t20));
    t22 = *((unsigned int *)t11);
    t27 = (t21 || t22);
    if (t27 > 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t11) > 0)
        goto LAB46;

LAB47:    if (*((unsigned int *)t15) > 0)
        goto LAB48;

LAB49:    memcpy(t14, t16, 8);

LAB50:    t23 = (t0 + 2852);
    xsi_vlogvar_wait_assign_value(t23, t14, 0, 0, 1, 0LL);
    xsi_set_current_line(111, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3036);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(112, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB23;

LAB25:    *((unsigned int *)t15) = 1;
    goto LAB28;

LAB27:    t12 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB28;

LAB29:    t23 = ((char*)((ng2)));
    t24 = (t0 + 2072U);
    t26 = *((char **)t24);
    memset(t33, 0, 8);
    t24 = (t33 + 4);
    t34 = (t26 + 4);
    t29 = *((unsigned int *)t26);
    t30 = (t29 >> 2);
    *((unsigned int *)t33) = t30;
    t31 = *((unsigned int *)t34);
    t32 = (t31 >> 2);
    *((unsigned int *)t24) = t32;
    t37 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t37 & 1073741823U);
    t38 = *((unsigned int *)t24);
    *((unsigned int *)t24) = (t38 & 1073741823U);
    xsi_vlogtype_concat(t25, 32, 32, 2U, t33, 30, t23, 2);
    t35 = ((char*)((ng1)));
    memset(t46, 0, 8);
    xsi_vlog_unsigned_minus(t46, 32, t25, 32, t35, 32);
    goto LAB30;

LAB31:    t36 = ((char*)((ng2)));
    t43 = (t0 + 2072U);
    t44 = *((char **)t43);
    memset(t48, 0, 8);
    t43 = (t48 + 4);
    t45 = (t44 + 4);
    t49 = *((unsigned int *)t44);
    t50 = (t49 >> 2);
    *((unsigned int *)t48) = t50;
    t51 = *((unsigned int *)t45);
    t52 = (t51 >> 2);
    *((unsigned int *)t43) = t52;
    t53 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t53 & 1073741823U);
    t54 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t54 & 1073741823U);
    xsi_vlogtype_concat(t47, 32, 32, 2U, t48, 30, t36, 2);
    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t14, 32, t46, 32, t47, 32);
    goto LAB37;

LAB35:    memcpy(t14, t46, 8);
    goto LAB37;

LAB38:    *((unsigned int *)t15) = 1;
    goto LAB41;

LAB40:    t4 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB41;

LAB42:    t12 = ((char*)((ng9)));
    goto LAB43;

LAB44:    t16 = ((char*)((ng3)));
    goto LAB45;

LAB46:    xsi_vlog_unsigned_bit_combine(t14, 32, t12, 32, t16, 32);
    goto LAB50;

LAB48:    memcpy(t14, t12, 8);
    goto LAB50;

LAB51:    *((unsigned int *)t14) = 1;
    goto LAB54;

LAB53:    t4 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB54;

LAB55:    t12 = (t0 + 2668);
    t16 = (t12 + 36U);
    t23 = *((char **)t16);
    memset(t15, 0, 8);
    t24 = (t23 + 4);
    t20 = *((unsigned int *)t24);
    t21 = (~(t20));
    t22 = *((unsigned int *)t23);
    t27 = (t22 & t21);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB61;

LAB59:    if (*((unsigned int *)t24) == 0)
        goto LAB58;

LAB60:    t26 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t26) = 1;

LAB61:    memset(t25, 0, 8);
    t34 = (t15 + 4);
    t29 = *((unsigned int *)t34);
    t30 = (~(t29));
    t31 = *((unsigned int *)t15);
    t32 = (t31 & t30);
    t37 = (t32 & 1U);
    if (t37 != 0)
        goto LAB62;

LAB63:    if (*((unsigned int *)t34) != 0)
        goto LAB64;

LAB65:    t38 = *((unsigned int *)t14);
    t39 = *((unsigned int *)t25);
    t40 = (t38 & t39);
    *((unsigned int *)t33) = t40;
    t36 = (t14 + 4);
    t43 = (t25 + 4);
    t44 = (t33 + 4);
    t41 = *((unsigned int *)t36);
    t42 = *((unsigned int *)t43);
    t49 = (t41 | t42);
    *((unsigned int *)t44) = t49;
    t50 = *((unsigned int *)t44);
    t51 = (t50 != 0);
    if (t51 == 1)
        goto LAB66;

LAB67:
LAB68:    goto LAB57;

LAB58:    *((unsigned int *)t15) = 1;
    goto LAB61;

LAB62:    *((unsigned int *)t25) = 1;
    goto LAB65;

LAB64:    t35 = (t25 + 4);
    *((unsigned int *)t25) = 1;
    *((unsigned int *)t35) = 1;
    goto LAB65;

LAB66:    t52 = *((unsigned int *)t33);
    t53 = *((unsigned int *)t44);
    *((unsigned int *)t33) = (t52 | t53);
    t45 = (t14 + 4);
    t55 = (t25 + 4);
    t54 = *((unsigned int *)t14);
    t56 = (~(t54));
    t57 = *((unsigned int *)t45);
    t58 = (~(t57));
    t59 = *((unsigned int *)t25);
    t60 = (~(t59));
    t61 = *((unsigned int *)t55);
    t62 = (~(t61));
    t13 = (t56 & t58);
    t63 = (t60 & t62);
    t64 = (~(t13));
    t65 = (~(t63));
    t66 = *((unsigned int *)t44);
    *((unsigned int *)t44) = (t66 & t64);
    t67 = *((unsigned int *)t44);
    *((unsigned int *)t44) = (t67 & t65);
    t68 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t68 & t64);
    t69 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t69 & t65);
    goto LAB68;

LAB69:    xsi_set_current_line(114, ng0);

LAB72:    xsi_set_current_line(115, ng0);
    t76 = (t0 + 1980U);
    t77 = *((char **)t76);
    memset(t47, 0, 8);
    t76 = (t77 + 4);
    t78 = *((unsigned int *)t76);
    t79 = (~(t78));
    t80 = *((unsigned int *)t77);
    t81 = (t80 & t79);
    t82 = (t81 & 1U);
    if (t82 != 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t76) != 0)
        goto LAB75;

LAB76:    t84 = (t47 + 4);
    t85 = *((unsigned int *)t47);
    t86 = *((unsigned int *)t84);
    t87 = (t85 || t86);
    if (t87 > 0)
        goto LAB77;

LAB78:    t101 = *((unsigned int *)t47);
    t102 = (~(t101));
    t103 = *((unsigned int *)t84);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB79;

LAB80:    if (*((unsigned int *)t84) > 0)
        goto LAB81;

LAB82:    if (*((unsigned int *)t47) > 0)
        goto LAB83;

LAB84:    memcpy(t46, t105, 8);

LAB85:    t117 = (t0 + 3128);
    xsi_vlogvar_wait_assign_value(t117, t46, 0, 0, 32, 0LL);
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 1980U);
    t3 = *((char **)t2);
    memset(t15, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB86;

LAB87:    if (*((unsigned int *)t2) != 0)
        goto LAB88;

LAB89:    t11 = (t15 + 4);
    t17 = *((unsigned int *)t15);
    t18 = *((unsigned int *)t11);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB90;

LAB91:    t20 = *((unsigned int *)t15);
    t21 = (~(t20));
    t22 = *((unsigned int *)t11);
    t27 = (t21 || t22);
    if (t27 > 0)
        goto LAB92;

LAB93:    if (*((unsigned int *)t11) > 0)
        goto LAB94;

LAB95:    if (*((unsigned int *)t15) > 0)
        goto LAB96;

LAB97:    memcpy(t14, t16, 8);

LAB98:    t23 = (t0 + 2852);
    xsi_vlogvar_wait_assign_value(t23, t14, 0, 0, 1, 0LL);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 1244U);
    t3 = *((char **)t2);
    t2 = (t0 + 3036);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 5, 0LL);
    xsi_set_current_line(118, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB71;

LAB73:    *((unsigned int *)t47) = 1;
    goto LAB76;

LAB75:    t83 = (t47 + 4);
    *((unsigned int *)t47) = 1;
    *((unsigned int *)t83) = 1;
    goto LAB76;

LAB77:    t88 = ((char*)((ng2)));
    t90 = (t0 + 2072U);
    t91 = *((char **)t90);
    memset(t89, 0, 8);
    t90 = (t89 + 4);
    t92 = (t91 + 4);
    t93 = *((unsigned int *)t91);
    t94 = (t93 >> 2);
    *((unsigned int *)t89) = t94;
    t95 = *((unsigned int *)t92);
    t96 = (t95 >> 2);
    *((unsigned int *)t90) = t96;
    t97 = *((unsigned int *)t89);
    *((unsigned int *)t89) = (t97 & 1073741823U);
    t98 = *((unsigned int *)t90);
    *((unsigned int *)t90) = (t98 & 1073741823U);
    xsi_vlogtype_concat(t48, 32, 32, 2U, t89, 30, t88, 2);
    t99 = ((char*)((ng1)));
    memset(t100, 0, 8);
    xsi_vlog_unsigned_minus(t100, 32, t48, 32, t99, 32);
    goto LAB78;

LAB79:    t106 = ((char*)((ng2)));
    t108 = (t0 + 2072U);
    t109 = *((char **)t108);
    memset(t107, 0, 8);
    t108 = (t107 + 4);
    t110 = (t109 + 4);
    t111 = *((unsigned int *)t109);
    t112 = (t111 >> 2);
    *((unsigned int *)t107) = t112;
    t113 = *((unsigned int *)t110);
    t114 = (t113 >> 2);
    *((unsigned int *)t108) = t114;
    t115 = *((unsigned int *)t107);
    *((unsigned int *)t107) = (t115 & 1073741823U);
    t116 = *((unsigned int *)t108);
    *((unsigned int *)t108) = (t116 & 1073741823U);
    xsi_vlogtype_concat(t105, 32, 32, 2U, t107, 30, t106, 2);
    goto LAB80;

LAB81:    xsi_vlog_unsigned_bit_combine(t46, 32, t100, 32, t105, 32);
    goto LAB85;

LAB83:    memcpy(t46, t100, 8);
    goto LAB85;

LAB86:    *((unsigned int *)t15) = 1;
    goto LAB89;

LAB88:    t4 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB89;

LAB90:    t12 = ((char*)((ng9)));
    goto LAB91;

LAB92:    t16 = ((char*)((ng3)));
    goto LAB93;

LAB94:    xsi_vlog_unsigned_bit_combine(t14, 32, t12, 32, t16, 32);
    goto LAB98;

LAB96:    memcpy(t14, t12, 8);
    goto LAB98;

LAB99:    xsi_set_current_line(120, ng0);
    t4 = ((char*)((ng3)));
    t11 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t11, t4, 0, 0, 1, 0LL);
    goto LAB101;

LAB102:    xsi_set_current_line(121, ng0);
    t4 = ((char*)((ng9)));
    t11 = (t0 + 2668);
    xsi_vlogvar_wait_assign_value(t11, t4, 0, 0, 1, 0LL);
    goto LAB104;

}


extern void work_m_00000000002874411349_3975733304_init()
{
	static char *pe[] = {(void *)Cont_40_0,(void *)NetDecl_59_1,(void *)NetDecl_64_2,(void *)Initial_70_3,(void *)Cont_80_4,(void *)Cont_81_5,(void *)Cont_82_6,(void *)Cont_83_7,(void *)Always_88_8};
	xsi_register_didat("work_m_00000000002874411349_3975733304", "isim/tb_isim_beh.exe.sim/work/m_00000000002874411349_3975733304.didat");
	xsi_register_executes(pe);
}
